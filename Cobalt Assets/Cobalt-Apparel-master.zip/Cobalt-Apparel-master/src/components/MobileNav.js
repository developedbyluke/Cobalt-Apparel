import React from 'react';

const MobileNav = () => {
  return (
    <ul>
      <li>luke</li>
      <li>is</li>
      <li>cool</li>
    </ul>
  );
};

export default MobileNav;
